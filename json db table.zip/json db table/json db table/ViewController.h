//
//  ViewController.h
//  json db table
//
//  Created by Sagar on 10/10/15.
//  Copyright © 2015 Sagar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFSQLManager.h"
#import <sqlite3.h>
@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>


@end

