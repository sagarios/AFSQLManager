//
//  AppDelegate.h
//  json db table
//
//  Created by Sagar on 10/10/15.
//  Copyright © 2015 Sagar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

